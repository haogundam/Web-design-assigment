window.onload = init;

function init() {
   document.forms[0].onsubmit = function() {
      if (this.checkValidity()) alert("Your delivery info have been recorded");
      return false;
   }
   
}