window.onload = init;


function init() {
    document.forms[0].onsubmit = function() {
       if (this.checkValidity()) alert("Your message has sent sucessfully.");
       return false;
    }
    
 }